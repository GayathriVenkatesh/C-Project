#ifndef VFS_4_INCLUDED
#define VFS_4_INCLUDED

int vfsmovedir(char *, char *);

int vfsaddfile(char *, char *, char *);

int vfscopyfile(char *, char *);

#endif 
